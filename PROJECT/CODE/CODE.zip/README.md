# Python source and verification

Entrypoint for the 30-epoch follow-up: `scripts/full_epoch_pilot.py`.
Legacy fixed-216-update modules are under `scripts/`; locked settings are in `protocol.json`.

Official complete source, including launch notebooks and later updates:
https://github.com/ID9999999999999/DL-Computer-vision/tree/nazih-training-set-size-20261109/COURSEWORK_NAZIH

This copy is intended for reading/replication. Use the version-controlled GitHub source as the authoritative exact code snapshot. Original model weights and all evaluation data are packaged separately in the submission folder.
