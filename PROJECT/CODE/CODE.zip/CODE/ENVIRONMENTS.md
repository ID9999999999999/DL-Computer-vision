# Executed software environments

The original fixed-budget training used the strict environment in `protocol.json`, including CPU-only torch 2.15.0+cpu, torchvision 0.29.2+cpu, NumPy 2.5.4 and Pillow 13.0.0. Its `requirements.txt` is a historical record, **not a universal cross-platform install lock**.

The 30-full-epoch Tesla T4 runs used torch 2.14.1+cu130, torchvision 0.29.1+cu130, NumPy 2.4.6 and Pillow 11.3.0 (Python 3.13.16). See each `COMPLETE.json` for recorded environment details. Exact GPU wheels and device availability depend on runtime. The standalone audit needs only Python 3.11+ standard library.
