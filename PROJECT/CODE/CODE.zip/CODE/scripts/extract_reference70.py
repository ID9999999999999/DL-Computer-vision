"""Safely restore the exactly recorded 70 historical input PNGs from the official ZIP."""
from __future__ import annotations
import argparse,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def sha_file(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for c in iter(lambda:f.read(4*1024*1024),b""):h.update(c)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--archive',required=True,type=Path,help='Original KolektorSDD2.zip')
    args=ap.parse_args()
    cfg=json.loads((ROOT/'protocol.json').read_text())
    assert sha_file(args.archive)==cfg['target_archive_sha256'], 'Incorrect official archive SHA256'
    rows=json.loads((ROOT/'input'/'target_manifest.json').read_text())
    assert len(rows)==70
    dest=ROOT/'input'/'train';dest.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(args.archive) as z:
        for row in rows:
            name=row['zip_path']
            assert name.startswith('train/') and name.endswith('.png') and '/' not in name[6:]
            data=z.read(name)
            assert hashlib.sha256(data).hexdigest()==row['sha256'],name
            p=dest/Path(name).name
            if p.exists():
                assert sha_file(p)==row['sha256'],f'Unexpected existing file: {p}'
            else:p.write_bytes(data)
    print('PASS: 70 exact source PNGs extracted and SHA256 verified')

if __name__=='__main__':main()
