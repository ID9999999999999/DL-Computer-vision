"""Verify the frozen studies from a clean unpacked copy, without training or internet.

Usage: python CODE/scripts/audit_submission.py --results RESULTS --out AUDIT
The two zip files CODE.zip and RESULTS.zip must have been extracted as sibling
folders. This script reads only stored, genuine experiment records.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import json
import math
from pathlib import Path


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path: Path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(4*1024*1024),b""):
            h.update(block)
    return h.hexdigest()


def metrics(predictions):
    assert len(predictions)==1004, "Expected 1004 official test predictions"
    cm=[[0,0],[0,0]]
    for p in predictions:
        y=p["label"]; pred=p["prediction"]
        assert y in (0,1) and pred in (0,1)
        assert len(p["sha256"])==64 and p["path"].startswith("test/")
        assert isinstance(p["defect_score"],(int,float)) and math.isfinite(p["defect_score"])
        cm[y][pred]+=1
    assert [sum(row) for row in cm]==[894,110]
    macro=sum(2*cm[c][c]/(sum(cm[c])+sum(row[c] for row in cm)) for c in (0,1))/2
    return cm, macro, (cm[0][0]+cm[1][1])/1004, cm[1][1]/110, cm[0][1]/894


def audit(results:Path,out:Path):
    original=list(sorted((results/'evaluations').glob('eval_size*_seed*_*.json')))
    histories=list(sorted((results/'training_metadata').glob('size*_seed*_*.json')))
    baselines=list(sorted((results/'historical'/'baseline_eval').glob('eval_*.json')))
    baseline_train=list(sorted((results/'historical'/'baseline_train').glob('target_train_*.json')))
    complete=list(sorted((results/'full_epochs').glob('*/COMPLETE.json')))
    splits=list(sorted((results/'full_epochs').glob('*/split.json')))
    assert (len(original),len(histories),len(baselines),len(baseline_train),len(complete),len(splits))==(18,18,6,6,8,8)
    manifest=load(Path(__file__).resolve().parents[1]/'input'/'test_manifest.json')
    test_hashes=[r['sha256'] for r in manifest]
    assert len(test_hashes)==len(set(test_hashes))==1004
    assert collections.Counter(r['label'] for r in manifest)=={0:894,1:110}
    legacy={}
    for path in original:
        obj=load(path)
        key=(obj['size'],obj['seed'],obj['loss'])
        assert key not in legacy
        assert path.name==f'eval_size{key[0]}_seed{key[1]}_{key[2]}.json'
        preds=obj['predictions'];cm,f1,acc,rec,fpr=metrics(preds)
        assert [p['sha256'] for p in preds]==test_hashes
        assert cm==obj['metrics']['confusion_matrix']
        for k,v in [('macro_f1',f1),('accuracy',acc),('defective_recall',rec),('normal_fpr',fpr)]:
            assert math.isclose(v,obj['metrics'][k],abs_tol=1e-11)
        legacy[key]=obj
    assert len(legacy)==18
    assert set(k[0] for k in legacy)=={140,280,420}
    assert set(k[1] for k in legacy)=={20261028,20261029,20261030}
    assert set(k[2] for k in legacy)=={'ce','poly1'}
    for path in baselines:
        obj=load(path)
        assert obj['seed'] in (20261028,20261029,20261030)
        assert obj['arm'] in ('ce','poly1')
        p=obj['predictions']
        assert len(p)==1004
        assert [row['sha256'] for row in p]==test_hashes
        assert sum(a['label'] != a['prediction'] for a in p)>=0
    for path in histories:
        o=load(path)
        assert (o['size'],o['seed'],o['loss']) in legacy
        assert o['total_optimizer_steps']==216
        assert len(o['train_history'])==12
        assert o['checkpoint_sha256']==legacy[(o['size'],o['seed'],o['loss'])]['checkpoint_sha256']
    pairs={}
    for f in complete:
        x=load(f);id=x['identity']; n=id['size'];seed=id['seed'];loss=id['loss']
        assert seed==20261028 and n in (70,140,280,420) and loss in ('ce','poly1')
        assert f.parent.name==f'n{n}_seed{seed}_{loss}'
        assert x['official_test_evaluated'] is False
        assert id['epochs']==30 and id['batch_size']==4
        history=x['history']
        assert len(history)==30
        steps=(n+3)//4
        assert all(h['full_epoch']==i and h['training_optimizer_steps']==steps and h['training_samples_seen']==n for i,h in enumerate(history,1))
        assert id['total_planned_optimizer_steps']==30*steps
        best=max(h['validation']['macro_f1'] for h in history)
        first=next(h['full_epoch'] for h in history if math.isclose(h['validation']['macro_f1'],best,rel_tol=0,abs_tol=1e-12))
        assert x['best_epoch']==first and math.isclose(best,x['best_validation_macro_f1'],abs_tol=1e-12)
        assert len(x['best_model_sha256'])==64 and len(x['split_sha256'])==64
        split=f.parent/'split.json'
        assert digest(split)==x['split_sha256']
        payload=load(split)
        train=payload['training_rows'];val=payload['validation_rows']
        assert len(train)==n and len(val)==180
        assert collections.Counter(y['label'] for y in train)=={0:n//2,1:n//2}
        assert collections.Counter(y['label'] for y in val)=={0:150,1:30}
        assert len(set(y['sha256'] for y in train))==n
        assert not (set(y['sha256'] for y in train)&set(y['sha256'] for y in val))
        assert not(set(y['sha256'] for y in val)&set(test_hashes))
        assert n not in pairs or loss not in pairs[n]
        pairs.setdefault(n,{})[loss]=(x,payload)
    assert set(pairs)=={70,140,280,420}
    for n,pair in pairs.items():
        assert set(pair)=={'ce','poly1'}
        assert pair['ce'][1]['validation_rows']==pair['poly1'][1]['validation_rows']
        assert pair['ce'][1]['training_rows']==pair['poly1'][1]['training_rows']
    reference=pairs[420]['ce'][1]['validation_rows']
    assert all(pair['ce'][1]['validation_rows']==reference for pair in pairs.values())
    ce=legacy[(420,20261028,'ce')]
    poly=legacy[(420,20261028,'poly1')]
    assert [p['sha256'] for p in ce['predictions']]==[p['sha256'] for p in poly['predictions']]
    rows=[]
    for a,b in zip(ce['predictions'],poly['predictions']):
        if a['label']==a['prediction'] and b['label']==b['prediction']:continue
        def error(p):
            if p['label']==p['prediction']:return 'Correct'
            return 'False positive' if p['label']==0 else 'False negative'
        rows.append({'image':a['path'],'sha256':a['sha256'],'true_label':a['label'],
                     'ce_prediction':a['prediction'],'ce_error':error(a),'ce_margin':round(a['defect_score'],6),
                     'poly1_prediction':b['prediction'],'poly1_error':error(b),'poly1_margin':round(b['defect_score'],6)})
    assert rows
    out.mkdir(parents=True,exist_ok=True)
    fields=list(rows[0])
    with (out/'ERROR_CASES.csv').open('w',encoding='utf-8',newline='') as file:
        w=csv.DictWriter(file,fieldnames=fields);w.writeheader();w.writerows(rows)
    bad_ce={r['image'] for r in rows if r['ce_error']!='Correct'}
    bad_poly={r['image'] for r in rows if r['poly1_error']!='Correct'}
    both=bad_ce&bad_poly
    fp_both=[x for x in rows if x['ce_error']==x['poly1_error']=='False positive']
    fn_both=[x for x in rows if x['ce_error']==x['poly1_error']=='False negative']
    fp_close=[x for x in rows if x['ce_error']=='False positive' and abs(x['ce_margin'])<0.10]
    fn_close=[x for x in rows if x['ce_error']=='False negative' and abs(x['ce_margin'])<0.10]
    examples=[]
    for category,cases in [('Shared false positive',fp_both),('Shared false negative',fn_both),
                           ('Near-boundary false positive (CE)',fp_close),('Near-boundary false negative (CE)',fn_close)]:
        unused=next((case for case in cases if case['image'] not in {p['image'] for _,p in examples}),None)
        if unused is not None:examples.append((category,unused))
    cases_table='\n'.join(f"| `{p['image']}` | {name} | {p['true_label']} | {p['ce_prediction']} | {p['ce_margin']:+.3f} | {p['poly1_prediction']} | {p['poly1_margin']:+.3f} |" for name,p in examples)
    legacy_cm_ce=ce['metrics']['confusion_matrix'];legacy_cm_poly=poly['metrics']['confusion_matrix']
    report=f"""# Error analysis — preserved exploratory test predictions

**Frozen comparison:** 420 training images, seed 20261028, Cross-Entropy vs Poly-1. Evaluation data: the previously inspected official test sample (1,004 images). This is a **diagnostic analysis**, not an independent test claim. No models were retrained, thresholds tuned, or predictions altered.

## Aggregate false decisions

| Method | TP | FN | FP | TN | Macro-F1 | Defect recall | Normal FPR |
|---|---:|---:|---:|---:|---:|---:|---:|
| Cross-Entropy | {legacy_cm_ce[1][1]} | {legacy_cm_ce[1][0]} | {legacy_cm_ce[0][1]} | {legacy_cm_ce[0][0]} | {ce['metrics']['macro_f1']:.4f} | {ce['metrics']['defective_recall']:.4f} | {ce['metrics']['normal_fpr']:.4f} |
| Poly-1 | {legacy_cm_poly[1][1]} | {legacy_cm_poly[1][0]} | {legacy_cm_poly[0][1]} | {legacy_cm_poly[0][0]} | {poly['metrics']['macro_f1']:.4f} | {poly['metrics']['defective_recall']:.4f} | {poly['metrics']['normal_fpr']:.4f} |

**Failure behavior:** CE misses {legacy_cm_ce[1][0]} of 110 real defects and raises {legacy_cm_ce[0][1]} false alarms among 894 normal images. Poly-1 misses {legacy_cm_poly[1][0]} defects and raises {legacy_cm_poly[0][1]} false alarms. Poly-1 reduces false alarms by {legacy_cm_ce[0][1]-legacy_cm_poly[0][1]} but misses {legacy_cm_poly[1][0]-legacy_cm_ce[1][0]} more defects; therefore choosing a method requires knowing the operational cost of missed defects versus false rejects.

There are **{len(both)} image IDs misclassified by both models**, with **{len(bad_ce-bad_poly)} errors unique to CE** and **{len(bad_poly-bad_ce)} errors unique to Poly-1**. This distinguishes shared blind spots from loss-specific behavior; equal aggregate error counts would not establish identity-level equivalence.

## Traceable error cases


A positive score margin means prediction 'defective'; a negative score means 'normal'. Near-zero margins show a decision close to the fixed argmax boundary, **not** a calibrated confidence value.

| Official image | Pattern | True class (0=normal) | CE predicted | CE margin | Poly-1 predicted | Poly-1 margin |
|---|---|---:|---:|---:|---:|---:|
{cases_table}

**Case interpretation:** A false negative is a true defect sent to the normal class (potential missed inspection); a false positive sends a normal sample to the defective class (potential unnecessary rejection). Shared false negatives merit additional visual inspection of the original images and defect masks before claiming that defect size, contrast, illumination, or morphology caused them. Those visual causes **cannot** be established from the saved numeric predictions alone. Example paths and the full reproducible list of misclassifications are in `ERROR_CASES.csv`.

## Integrity and limits

- Predictions were rechecked against the frozen official test-manifest SHA256 order.
- All 18 new evaluation JSONs had their stored confusion matrices and numeric scores independently recomputed from their 1,004 prediction rows.
- Original six historical evaluations, 18 new training metadata records, and eight 30-full-epoch histories/splits were checked for counts and internal consistency.
- The same validation rows (n=180) were verified across all eight full-epoch runs, with zero SHA256 identity overlap with training samples.
- No source-image thumbnails are included because the complete official ZIP was unavailable in this clean audit environment. A visual explanation of texture/lighting would be speculative.
- Numeric record consistency does not replace a fresh clean GPU retraining, nor prove physical-specimen independence.
"""
    (out/'ERROR_ANALYSIS.md').write_text(report,encoding='utf-8')
    summary={'new_original_evaluations_verified':len(original),'historical_evaluations_verified':len(baselines),
             'training_metadata_verified':len(histories),'full_epoch_runs_verified':len(complete),
             'all_full_epoch_validation_identical':True,
             'ce_420_false_negatives':legacy_cm_ce[1][0], 'ce_420_false_positives':legacy_cm_ce[0][1],
             'poly1_420_false_negatives':legacy_cm_poly[1][0],'poly1_420_false_positives':legacy_cm_poly[0][1],
             'either_model_error_cases':len(rows),'shared_error_cases':len(both),
             'original_test_independent':False,'full_gpu_retraining_performed':False}
    (out/'AUDIT_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2));return summary

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--results',type=Path,default=Path(__file__).resolve().parents[2]/'RESULTS')
    parser.add_argument('--out',type=Path,default=Path.cwd()/'AUDIT')
    args=parser.parse_args()
    audit(args.results,args.out)
