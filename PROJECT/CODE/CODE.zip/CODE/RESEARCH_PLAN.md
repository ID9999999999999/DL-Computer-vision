# Research plan (historical decisions, final KSDD2 study)

**Classification task:** Normal (0) versus Defective (1) industrial surface images. Public labelled dataset: KolektorSDD2.

**Testable question:** Does replacing Cross-Entropy with Poly-1 improve Macro-F1 or defective recall under the same ResNet18 architecture, training image subset, random seed and optimizer settings?

**Baseline:** ImageNet-pretrained ResNet18, end-to-end fine tuning, Cross-Entropy.

**Paper idea implemented:** Leng et al. (2022), *PolyLoss: A Polynomial Expansion Perspective of Classification Loss Functions*, ICLR. Used the classification loss `CE + (1-p_true)` with epsilon 1, implemented and verified in `scripts/core.py`.

**Second paper considered:** Akhmedova & Körber (2024), *Next Generation Loss Function for Image Classification*, arXiv:2404.12948. Not implemented.

**Controlled comparison:** Study A: 216 optimizer updates (three seeds, four nested training subsets, two losses; six 70-image historical reference records). Study B: eight genuine 30-epoch runs (one seed, four subsets, two losses), all assessed on the same disjoint 180-image internal validation. Their metrics and compute budgets are distinct; scores are not pooled across evaluation populations.

**Safety of conclusions:** Earlier official TEST inspection makes Study A exploratory; Study B reports selected internal Validation, not blind test performance. Physical-specimen independence is not established. Detailed numerical cases are in `RESULTS/ERROR_ANALYSIS.md` after extraction.
