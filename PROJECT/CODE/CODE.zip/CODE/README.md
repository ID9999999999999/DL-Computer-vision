# SOURCE CODE — RESNET18 / CE / POLY-1

## Reproduce the saved calculations (no GPU or dataset download required)

1. Extract `CODE.zip` and `RESULTS.zip` next to each other, as `CODE/` and `RESULTS/`.
2. Install Python 3.11+ (the audit uses only the standard library).
3. Run from the directory containing both folders:

   `python CODE/scripts/audit_submission.py --results RESULTS --out AUDIT`

The audit validates all 18 new fixed-budget evaluation records, six historical references, 18 training histories, eight complete 30-full-epoch histories and their frozen validation splits. It writes `AUDIT_SUMMARY.json`, `ERROR_CASES.csv` and `ERROR_ANALYSIS.md`. Run it from a clean extracted directory to check that no hidden files are needed for **record verification**.

## Original training and optional new runs

- Original research protocol: `CODE/protocol.json` (fixed 216 updates, 3 seeds).
- Main modules: `CODE/scripts/{core,prepare,train,evaluate,full_epoch_pilot}.py`.
- Official data: `KolektorSDD2.zip` in the separate Drive dataset archive. Validate its SHA256 against `protocol.json`. **Do not put the ZIP into GitHub.**
- Recorded GPU run environment: Python 3.13.16; torch 2.14.1+cu130; torchvision 0.29.1+cu130; NumPy 2.4.6; Pillow 11.3.0. Tesla T4.
- Historical fixed-budget reference environment was different (see `protocol.json`); do not assert bitwise replication across environments.
- To inspect the 30-epoch CLI: `python CODE/scripts/full_epoch_pilot.py --help`. Its training requires additional official source data and `torch`/`torchvision`, and has **not** been independently rerun as part of this submission audit.
- The original tests need 70 PNG images, not included in this lightweight ZIP. With the verified original dataset ZIP available, recover them by running:

  `python CODE/scripts/extract_reference70.py --archive /path/to/KolektorSDD2.zip`

- Then from the `CODE/` directory run `python scripts/preflight.py` and `python scripts/test_pipeline.py` in the matching PyTorch environment. The first command verifies source hashes and historical references; the second checks the Poly-1 analytical gradient and sampling schedules. Preflight writes a *new* `CODE/results/preflight.json`; never overwrite archived evidence.
- For a full 30-epoch pilot, with a GPU and correct runtime packages installed, from the folder containing `CODE/` run `python CODE/scripts/full_epoch_pilot.py --archive /path/to/KolektorSDD2.zip --check-only`. Do not rerun any completed experiment in a shared output path. The 853 MB original archive was **not** accessible to the clean sandbox audit, so that dataset-dependent check could not be run here.

The recorded runs, saved checkpoints and metadata are preserved; this package does not fabricate a new training run or an untouched test result.
