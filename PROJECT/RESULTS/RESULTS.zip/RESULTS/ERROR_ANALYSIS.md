# Error analysis — preserved exploratory test predictions

**Frozen comparison:** 420 training images, seed 20261028, Cross-Entropy vs Poly-1. Evaluation data: the previously inspected official test sample (1,004 images). This is a **diagnostic analysis**, not an independent test claim. No models were retrained, thresholds tuned, or predictions altered.

## Aggregate false decisions

| Method | TP | FN | FP | TN | Macro-F1 | Defect recall | Normal FPR |
|---|---:|---:|---:|---:|---:|---:|---:|
| Cross-Entropy | 84 | 26 | 23 | 871 | 0.8734 | 0.7636 | 0.0257 |
| Poly-1 | 82 | 28 | 17 | 877 | 0.8798 | 0.7455 | 0.0190 |

**Failure behavior:** CE misses 26 of 110 real defects and raises 23 false alarms among 894 normal images. Poly-1 misses 28 defects and raises 17 false alarms. Poly-1 reduces false alarms by 6 but misses 2 more defects; therefore choosing a method requires knowing the operational cost of missed defects versus false rejects.

There are **41 image IDs misclassified by both models**, with **8 errors unique to CE** and **4 errors unique to Poly-1**. This distinguishes shared blind spots from loss-specific behavior; equal aggregate error counts would not establish identity-level equivalence.

## Traceable error cases


A positive score margin means prediction 'defective'; a negative score means 'normal'. Near-zero margins show a decision close to the fixed argmax boundary, **not** a calibrated confidence value.

| Official image | Pattern | True class (0=normal) | CE predicted | CE margin | Poly-1 predicted | Poly-1 margin |
|---|---|---:|---:|---:|---:|---:|
| `test/20043.png` | Shared false positive | 0 | 1 | +0.032 | 1 | +1.119 |
| `test/20139.png` | Shared false negative | 1 | 0 | -1.029 | 0 | -0.126 |
| `test/20759.png` | Near-boundary false positive (CE) | 0 | 1 | +0.017 | 0 | -0.023 |
| `test/20523.png` | Near-boundary false negative (CE) | 1 | 0 | -0.024 | 0 | -0.774 |

**Case interpretation:** A false negative is a true defect sent to the normal class (potential missed inspection); a false positive sends a normal sample to the defective class (potential unnecessary rejection). Shared false negatives merit additional visual inspection of the original images and defect masks before claiming that defect size, contrast, illumination, or morphology caused them. Those visual causes **cannot** be established from the saved numeric predictions alone. Example paths and the full reproducible list of misclassifications are in `ERROR_CASES.csv`.

## Integrity and limits

- Predictions were rechecked against the frozen official test-manifest SHA256 order.
- All 18 new evaluation JSONs had their stored confusion matrices and numeric scores independently recomputed from their 1,004 prediction rows.
- Original six historical evaluations, 18 new training metadata records, and eight 30-full-epoch histories/splits were checked for counts and internal consistency.
- The same validation rows (n=180) were verified across all eight full-epoch runs, with zero SHA256 identity overlap with training samples.
- No source-image thumbnails are included because the complete official ZIP was unavailable in this clean audit environment. A visual explanation of texture/lighting would be speculative.
- Numeric record consistency does not replace a fresh clean GPU retraining, nor prove physical-specimen independence.
