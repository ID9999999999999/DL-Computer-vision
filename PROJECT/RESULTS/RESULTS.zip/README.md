# Observed experiments only

Study A: 216 optimizer updates (18 new training/evaluation records, 6 archived historical pairs; 24 evaluated conditions in total).
Study B: eight 30-full-epoch runs for seed 20261028; each run has a COMPLETE.json history and its split.json.
All metrics are exploratory; Study B scores are internal validation, not a new independent test.
Models are provided separately in the MODELS folder.
